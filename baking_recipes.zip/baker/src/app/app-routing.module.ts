import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './dashboard/aboutus/aboutus.component';
import { AdminComponent } from './dashboard/admin/admin.component';
import { CakeComponent } from './dashboard/cake/cake.component';
import { ContactComponent } from './dashboard/contact/contact.component';
import { CookieComponent } from './dashboard/cookie/cookie.component';
import { CupcakeComponent } from './dashboard/cupcake/cupcake.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DonutComponent } from './dashboard/donut/donut.component';
import { HomeComponent } from './dashboard/home/home.component';
import { LoginComponent } from './dashboard/login/login.component';
import { PizzaComponent } from './dashboard/pizza/pizza.component';
import { ProductsComponent } from './dashboard/products/products.component';
import { RegisterComponent } from './dashboard/register/register.component';
import { RegisterdetailsComponent } from './dashboard/registerdetails/registerdetails.component';

const routes: Routes = [
  {path:"", component:DashboardComponent,
children:[
  {path:"",component:HomeComponent},
  {path:"aboutus",component:AboutusComponent},
  {path:"contact",component:ContactComponent},
  {path:"login",component:LoginComponent},
  {path:"register",component:RegisterComponent},
  {path:"registerdetails",component:RegisterdetailsComponent},
  {path:"products",component:ProductsComponent},
  {path:"admin",component:AdminComponent},
  {path:"cake",component:CakeComponent},
  {path:"cupcake",component:CupcakeComponent},
  {path:"donut",component:DonutComponent},
  {path:"pizza",component:PizzaComponent},
  {path:"cookie",component:CookieComponent}
]

}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
