import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  adminDetails:any={username:'',password:'',}
  error:any={uname:false,pass:false}
  constructor(private http:HttpClient, private route:Router) { }

  ngOnInit(): void {
  }
    admin(){
      let haserror = false;
      if(this.adminDetails.username == undefined ||this.adminDetails.username == "" )
    {
      this.error.uname = "required";
      haserror=true;
    }
    else
    {
      this.error.uname=false;
    }
    if(this.adminDetails.password == undefined ||this.adminDetails.password == "" )
    {
      this.error.pass = "required";
      haserror=true;
    }
    else
    {
      this.error.pass=false;
    }
    {
      if(haserror)
      {
        console.error(this.error)
        return;
      }
    }
  var formdata = new FormData();
  formdata.set("username",this.adminDetails.username)
  formdata.set("password",this.adminDetails.password)
  console.log(this.adminDetails)
  this.http.post("http://localhost:9005/admin/validateloginadmin/",formdata).subscribe((data:any)=>{console.log(data)
  if(data.status == 'success'){
    window.alert('Logged in successfully')
    this.route.navigate(['/registerdetails'])
  }
  else{
  window.alert('Users cannot login in. Redirect to user login page')
  this.route.navigate(['/login'])
  }  
})
  }

}
