import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cupcake',
  templateUrl: './cupcake.component.html',
  styleUrls: ['./cupcake.component.css']
})
export class CupcakeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
