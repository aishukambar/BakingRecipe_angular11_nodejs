import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { data } from 'jquery';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
registerDetails:any={fullname:'',email:'',username:'',password:'',phonenumber:'',address:'',}
error:any={fname:false,email:false,uname:false,pass:false,number:false, addrress:false}
  constructor(private http:HttpClient,private route:Router) { }

  ngOnInit(): void {
  }
  register(){
    let haserror = false;
    if(this.registerDetails.fullname == undefined ||this.registerDetails.fullname == "" )
    {
      this.error.fname = "required";
      haserror=true;
    }
    else
    {
      this.error.fname=false;
    }
    if(this.registerDetails.email == undefined || this.registerDetails.email == "")
    {
      this.error.email = "required";
      haserror=true;
    }
    else
    {
      this.error.email=false;
    }
    if(this.registerDetails.username == undefined || this.registerDetails.username == "")
    {
      this.error.uname = "required";
      haserror=true;
    }
    else
    {
      this.error.uname=false;
    }
    if(this.registerDetails.phonenumber == undefined || this.registerDetails.phonenumber == "")
    {
      this.error.number = "required";
      haserror=true;
    }
    else
    {
      this.error.number=false;
    }
    if(this.registerDetails.password == undefined || this.registerDetails.password == "")
    {
      this.error.pass = "required";
      haserror=true;
    }
    else
    {
      this.error.pass=false;
    }
    if(this.registerDetails.address == undefined || this.registerDetails.address == "")
    {
      this.error.addrress = "required";
      haserror=true;
    }
    else
    {
      this.error.addrress=false;
    }
    {
      if(haserror)
      {
        console.error(this.error)
        return;
      }
    }
    var formdata = new FormData();
    formdata.set("fullname",this.registerDetails.fullname)
    formdata.set("email",this.registerDetails.email)
    formdata.set("username",this.registerDetails.username)
    formdata.set("password",this.registerDetails.password)
    formdata.set("phonenumber",this.registerDetails.phonenumber)
    formdata.set("address",this.registerDetails.address)
    console.log(this.registerDetails)
    this.http.post("http://localhost:9005/admin/addRegister/",formdata).subscribe((data:any)=>{console.log(data)
    if(data.status == 'success'){
      window.alert('Registered successfully')
      this.route.navigate(['/login'])
    }
    else
    window.alert('Invalid details')
  })
  
  }
}
