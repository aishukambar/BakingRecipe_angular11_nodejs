import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { data } from 'jquery';
import { HomeComponent } from '../home/home.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginDetails:any={username:'',password:'',}
  error:any={uname:false,pass:false}

  constructor(private http:HttpClient, private route:Router) { }

  ngOnInit(): void {
  }

login(){
  let haserror=false;
  if(this.loginDetails.username==undefined || this.loginDetails.username == "")
  {
    this.error.uname="required";
    haserror=true;
  }
  else{
    this.error.uname=false;
  }
  if(this.loginDetails.password == "")
  {
    this.error.pass="required";
    haserror=true;
  }
  else{
    this.error.pass=false;
  }
  {
    if(haserror)
    {
      console.error(this.error)
      return;
  }
  }
  var formdata = new FormData;
  formdata.set("username",this.loginDetails.username)
  formdata.set("password",this.loginDetails.password)
  console.log(this.loginDetails)
  this.http.post("http://localhost:9005/admin/validatelogin/",formdata).subscribe((data:any)=>{console.log(data)
  if(data.status == 'success'){
    window.alert('Logged in successfully')
    this.route.navigate(['/products'])
  }
  else
  window.alert('Invalid login details')
})

}
}