import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-registerdetails',
  templateUrl: './registerdetails.component.html',
  styleUrls: ['./registerdetails.component.css']
})
export class RegisterdetailsComponent implements OnInit {

  title = 'datatables';
  dtOptions: DataTables.Settings = {};
  posts:any={id:'',fullname:'',email:'',username:'',password:'',phonenumber:'',address:''}
   
  constructor(private http: HttpClient) { }
   
  ngOnInit(): void {
    this.postDetails()  
    this.dtOptions = {
      pagingType:'full_numbers',
      pageLength: 10,
      processing: true
    };
  }
    postDetails(){
    this.http.get('http://localhost:9005/admin/ViewAllRegister/')
      .subscribe((data:any) => {
        this.posts = data.data;
        console.log(data.data)
    });
  }
}