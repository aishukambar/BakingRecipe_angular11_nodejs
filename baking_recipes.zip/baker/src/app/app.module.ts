import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AboutusComponent } from './dashboard/aboutus/aboutus.component';
import { ContactComponent } from './dashboard/contact/contact.component';
import { LoginComponent } from './dashboard/login/login.component';
import { RegisterComponent } from './dashboard/register/register.component';
import { RegisterdetailsComponent } from './dashboard/registerdetails/registerdetails.component';
import { ProductsComponent } from './dashboard/products/products.component';
import { DataTablesModule } from 'angular-datatables';
import { HttpClientModule } from '@angular/common/http';
import { AdminComponent } from './dashboard/admin/admin.component';
import { CakeComponent } from './dashboard/cake/cake.component';
import { CupcakeComponent } from './dashboard/cupcake/cupcake.component';
import { DonutComponent } from './dashboard/donut/donut.component';
import { PizzaComponent } from './dashboard/pizza/pizza.component';
import { CookieComponent } from './dashboard/cookie/cookie.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent, 
    AboutusComponent,
    ContactComponent,
    LoginComponent,
    RegisterComponent,
    RegisterdetailsComponent,
    ProductsComponent,
    AdminComponent,
    CakeComponent,
    CupcakeComponent,
    DonutComponent,
    PizzaComponent,
    CookieComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    DataTablesModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
