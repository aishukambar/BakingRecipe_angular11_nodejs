var express = require('express');
var router = express.Router();
var multer = require("multer");
var path = require("path");
var md5 = require("md5");
const userModel = require('../../model/admin/admin_model.js');
const { request, response } = require('express');
// router.use(uploadArray);
router.use(express.static('public'));
var common = require('../../config/common.js');


var storage = multer.diskStorage({
    destination: './uploads/profile',
    filename: (req, file, cb) => {
        return cb(null, `${file.fieldname}_${Date.now()}${path.extname(file.originalname)}`)
    }
})


var multer = require('multer');

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/')
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '.jpg') //Appending .jpg
  }
})


const upload = multer({ storage: storage })

//Super -admin login
router.post("/validateSuperAdmin", upload.any(), (req, res) => {
    var data = {};
    console.log(req.body.uname);

    data['email'] = req.body.email;
    data['password'] = md5(req.body.password);
    
     userModel.validateSuperAdmin(data, function(response){
        console.log(response);
        return res.send(response);
    })
});




// --------------------------------------------------------------------------------

//Insert Register
router.post("/addRegister", upload.any(), (req, res) => {
    var data = {};
    console.log(req.body.uname);

    data['fullname'] = req.body.fullname;
    data['email'] = req.body.email;
    data['username'] = req.body.username;
    data['password'] = md5(req.body.password);
    data['phonenumber'] = req.body.phonenumber;
    data['address'] = req.body.address;

    // console.log(data);
    userModel.addRegister(data, function(response){
        console.log(response);
        return res.send(response);
    })
});
//Validate login
router.post("/validatelogin", upload.any(), (req, res) => {
    var data = {};
    console.log(req.body.uname);
    data['username'] = req.body.username;
    data['password'] = md5(req.body.password);
    data['admin_user']=null

    // console.log(data);
    userModel.validatelogin(data, function(response){
        console.log(response);
        return res.send(response);
    })
});



//VIEW ALL Register List 
router.get("/ViewAllRegister/", (req, res) => {
        // common.checkToken(req,res, (uData,token) =>  {
        userModel.ViewAllRegister(function(response){
            console.log(response);
            return res.send(response);
        }) 
    // });
});

//VIEW ONE Register List 
router.get("/ViewOneRegister/:userid", (req, res) => {
    // common.checkToken(req,res, (uData,token) =>  {
    userModel.ViewOneRegister(req.params.userid, function(response){
        console.log(response);
        return res.send(response);
    }) 
// });
});

//validate admin login
router.post("/validateloginadmin", upload.any(), (req, res) => {
    var data = {};
    console.log(req.body.uname);
    data['username'] = req.body.username;
    data['password'] = md5(req.body.password);
    data['admin_user']='admin'
    // console.log(data);
    userModel.validateloginadmin(data, function(response){
        console.log(response);
        return res.send(response);
    })
});


module.exports = router;
